package com.love.lovelive.retrofit

import com.love.lovelive.interactors.ApiResponse
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Field
import retrofit2.http.FieldMap
import retrofit2.http.Path

interface AppApiServices {


    /**
     * Login
     */

    //    suspend fun login(param: LoginRequest): Response<ApiResponse<LoginResponse>>



}