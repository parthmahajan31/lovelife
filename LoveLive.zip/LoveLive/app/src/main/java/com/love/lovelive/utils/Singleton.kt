package com.love.lovelive.utils


object Singleton {

 var privacy_terms = 2
 var forgot_pass = 0
}