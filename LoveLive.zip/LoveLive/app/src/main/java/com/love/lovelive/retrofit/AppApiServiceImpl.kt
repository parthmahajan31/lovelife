package com.love.lovelive.retrofit

import com.love.lovelive.interactors.ApiResponse
import okhttp3.RequestBody
import retrofit2.Response

class AppApiServiceImpl

constructor(private val apiServices: ApiService) : AppApiServices {


    //    override suspend fun userRegister(hashMap:HashMap<String, RequestBody>,profile_image: MultipartBody.Part):Response<ApiResponse<RegisterModel>>{
//        return apiService.userRegister(hashMap,profile_image)
//    }



}