package com.love.lovelive.viewmodel


interface BaseViewState