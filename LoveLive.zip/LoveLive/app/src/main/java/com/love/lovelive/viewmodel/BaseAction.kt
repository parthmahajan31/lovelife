package com.love.lovelive.viewmodel


interface BaseAction