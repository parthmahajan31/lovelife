package com.love.lovelive.utils

interface DrawerLocker {
    fun setDrawerEnabled(enabled: Boolean)
}